package com.jwbook2.jwbook2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jwbook2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
